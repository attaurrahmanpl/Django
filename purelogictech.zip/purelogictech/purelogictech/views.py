from django.http import HttpResponse
from django.shortcuts import render

def homePage(request):

    data = {
        'title':'Home page',
        'bodyData':"this is body data",
         'clist': ['php' , 'python' , 'java']    
    }
   
    return render(request , "index.html" , data)

def about_us(request):

    return HttpResponse("welcome to purelogictech")

def course(request):

    return HttpResponse("welcome to purelogictech Course URL")

def coursedetails(request , courseid):

    return HttpResponse(courseid)
